package com.capgemini.salesmanagement.service;


import java.io.IOException;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;


import com.capgemini.salesmanagement.bean.ProductBean;
import com.capgemini.salesmanagement.dao.IProductDAO;
import com.capgemini.salesmanagement.dao.ProductDAO;
import com.capgemini.salesmanagement.exception.ProductException;

public class ProductService implements IProductService{
	 IProductDAO productDao=new ProductDAO();
	@Override
	public ProductBean getProductDetails(int productCode) throws ClassNotFoundException, IOException, SQLException {
		ProductBean product=new ProductBean();
		product=productDao.getProductDetails(productCode);

return product;
		
	}

	@Override
	public boolean insertSalesDetails(ProductBean product1) throws ClassNotFoundException, ProductException, IOException, SQLException {
		boolean productseq;
		productseq=productDao.insertSalesDetails(product1);
	
		return productseq;
	}

	public void validateBook(ProductBean product) {
		 List<String> validationErrors=new ArrayList<String>();
			
			/*if(!(isValidSalesId(product.getSalesid())))
			{
				validationErrors.add("\n book Name should be in Alphabets and minimum 3 characters long\n");
				
			}*/
			if(!(isValidQuantity(product.getQuantity())))
					{
				
				
				validationErrors.add("\n Amount Should be a positive Number \n" );
			}
			
		
	


		
	}

	

	private boolean isValidQuantity(int quantity) {
		
			return (quantity>0);
		
	}

}
