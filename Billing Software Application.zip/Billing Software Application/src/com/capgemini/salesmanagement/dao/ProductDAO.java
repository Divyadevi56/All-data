package com.capgemini.salesmanagement.dao;

import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Scanner;

import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;

import com.capgemini.salesmanagement.bean.ProductBean;
import com.capgemini.salesmanagement.exception.ProductException;
import com.capgemini.salesmanagement.util.DBConnection;

public class ProductDAO implements IProductDAO {
	
	Logger logger=Logger.getRootLogger();
	public ProductDAO()
	{
	PropertyConfigurator.configure("resources//log4j.properties");
	
	}
	@Override
	public ProductBean getProductDetails(int productCode) throws ClassNotFoundException, IOException, SQLException {
		
			Connection connection=DBConnection.getConnection();
			ResultSet resultSet;
			PreparedStatement pst=null;
			Scanner sc=new Scanner(System.in);
			ProductBean product=new ProductBean();
			
			pst=connection.prepareStatement(QueryMapper.View_product_details);
			 
			pst.setInt(1,sc.nextInt());
			resultSet=pst.executeQuery();
			while(resultSet.next())
			{
				
				product.setProductCode(resultSet.getInt(1));
				product.setProductName(resultSet.getString(2));
				product.setProductCategory(resultSet.getString(3));
				product.setProductDescription(resultSet.getString(4));
				product.setProductPrice(resultSet.getInt(5));
				
			   
			}
			
			if( product != null)
			{
				logger.info("Record Found Successfully");
				return product;
			}
			else
			{
				logger.info("Record Not Found Successfully");
				return null;
			}
	}
			
	

	@Override
	public boolean insertSalesDetails(ProductBean product) throws ProductException, ClassNotFoundException, IOException, SQLException {
		Connection con=DBConnection.getConnection();
		PreparedStatement pst=null;
		//PreparedStatement pst1=null;
		ResultSet resultSet=null;
		String bookId=null;
		int queryResult=0;
		try
		{
		
		 pst=con.prepareStatement(QueryMapper. Add_sales);
		pst.setInt(1,product.getSalesid());
		pst.setInt(2,product.getProductCode());
		pst.setInt(3,product.getQuantity());
		pst.setString(4,product.getDate());
		pst.setInt(5,product.getLinetotal());
		
		queryResult=pst.executeUpdate();
		
		Statement st=con.createStatement();
		
		resultSet=st.executeQuery(QueryMapper.Add_sales_seq);
		String productCode1;
		while(resultSet.next())
		{
			productCode1=resultSet.getString(1);
		}
		
		
		if(queryResult==0)
		{
			logger.error("Insertion failed ");
			throw new ProductException("Inserting book details failed ");
		

		}
		else
		{
			logger.info("book details added successfully:");
			return true;
		}
		}catch(SQLException sql)
		{
			logger.error(sql.getMessage());
			System.out.println(sql);
		}
	
		return false;
	}

}
