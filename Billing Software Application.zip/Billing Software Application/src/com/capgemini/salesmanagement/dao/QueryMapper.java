package com.capgemini.salesmanagement.dao;

public interface QueryMapper {
	String Add_sales="insert into sales values(?,?,?,?,?)";
	String Add_sales_seq="select MAX(product_code) from sales";
	
	String View_product_details="select * from product where product_code=?";
	

}
