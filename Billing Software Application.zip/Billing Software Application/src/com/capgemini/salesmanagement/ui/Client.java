package com.capgemini.salesmanagement.ui;

import java.io.IOException;
import java.sql.SQLException;
import java.util.InputMismatchException;
import java.util.Scanner;

import javax.swing.plaf.synth.SynthToggleButtonUI;

import org.apache.log4j.Logger;

import com.capgemini.salesmanagement.bean.ProductBean;
import com.capgemini.salesmanagement.exception.ProductException;
import com.capgemini.salesmanagement.service.IProductService;
import com.capgemini.salesmanagement.service.ProductService;

public class Client {
	static Scanner sc=new Scanner(System.in);
	private static ProductService productService;
	static Logger logger = Logger.getRootLogger();

	
public static void main(String[] args) throws ClassNotFoundException, IOException, SQLException {
	 ProductBean product=new ProductBean();
	 
	 System.out.println("enter product Code");
	 ProductService iProductService = new ProductService();
	 productService=new ProductService();
		
int productCode=0;
product=productService.getProductDetails(productCode);
if(product!=null)
{
System.out.println(product);
}
else 
{
	System.out.println("product not available");
}

while(product==null)
{
	product=populateSalesDetails();
}
try
{
	boolean productCode1; 
	productService = new ProductService();
	productCode1 = productService.insertSalesDetails(product);

	//System.out.println("Sales details  has been successfully registered ");
	
}catch (ProductException productException) {
	logger.error("exception occured", productException);
	System.err.println("ERROR : "+ productException.getMessage());
} finally {
	productCode = 0;
	productService = null;
	product = null;
}



}

private static ProductBean populateSalesDetails() throws SQLException {
	ProductBean product=new ProductBean();
	System.out.println("enter salesid");
	product.setSalesid(sc.nextInt());
	
	System.out.println("enter productCode");
	product.setProductCode(sc.nextInt());
	
	
	System.out.println("enter quantity");
	//int bookPrice=sc.nextInt();
	
	try {
		
		
		product.setQuantity(sc.nextInt());
	
		}
		catch(InputMismatchException ime)
		{
			sc.nextLine();
			System.out.println("please enter a numeric value for price,try again");
		}
	System.out.println("enter sales date");
	product.setDate(sc.next());

	productService=new ProductService();
	
	productService.validateBook(product);
	return product;
	

	

}

}
