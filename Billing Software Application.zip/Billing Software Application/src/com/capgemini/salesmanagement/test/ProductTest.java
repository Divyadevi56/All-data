package com.capgemini.salesmanagement.test;


	
	import static org.junit.Assert.assertEquals;
	import static org.junit.Assert.assertNotNull;
	import static org.junit.Assert.assertTrue;

	import java.io.IOException;
	import java.sql.Date;
	import java.sql.SQLException;
	import java.time.LocalDate;

		import org.junit.After;
		import org.junit.AfterClass;
		import org.junit.Assert;
		import org.junit.Before;
		import org.junit.BeforeClass;
		import org.junit.Ignore;
		import org.junit.Test;

import com.capgemini.salesmanagement.bean.ProductBean;
import com.capgemini.salesmanagement.dao.ProductDAO;
import com.capgemini.salesmanagement.exception.ProductException;

	

		

	public class ProductTest {

			static ProductDAO dao;
			static ProductBean product;

			@BeforeClass
			public static void initialize() {
				System.out.println("in before class");
				dao = new ProductDAO();
				product = new ProductBean();
			}

			@Test
			public void testAddsales() throws ProductException, ClassNotFoundException, IOException, SQLException {

				assertNotNull(dao.insertSalesDetails(product));

			}

			

			@Test
			public void ProductDetails() throws ProductException, ClassNotFoundException, IOException, SQLException {
				assertNotNull(dao.getProductDetails(0));
			}

	
		}

