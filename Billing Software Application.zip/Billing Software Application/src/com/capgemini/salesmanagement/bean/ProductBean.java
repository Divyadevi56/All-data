package com.capgemini.salesmanagement.bean;

public class ProductBean {
int productCode;
String productName;
String productCategory;
String productDescription;
int productPrice;
int salesid;
int quantity;
String date;
int linetotal;

public int getProductCode() {
	return productCode;
}
public void setProductCode(int productCode) {
	this.productCode = productCode;
}
public String getProductName() {
	return productName;
}
public void setProductName(String productName) {
	this.productName = productName;
}
public String getProductCategory() {
	return productCategory;
}
public void setProductCategory(String productCategory) {
	this.productCategory = productCategory;
}
public String getProductDescription() {
	return productDescription;
}
public void setProductDescription(String productDescription) {
	this.productDescription = productDescription;
}
public int getProductPrice() {
	return productPrice;
}
public void setProductPrice(int productPrice) {
	this.productPrice = productPrice;
}

public int getSalesid() {
	return salesid;
}
public void setSalesid(int salesid) {
	this.salesid = salesid;
}
public int getQuantity() {
	return quantity;
}
public void setQuantity(int quantity) {
	this.quantity = quantity;
}
public String getDate() {
	return date;
}
public void setDate(String date) {
	this.date = date;
}
public int getLinetotal() {
	return linetotal;
}
public void setLinetotal(int linetotal) {
	this.linetotal = linetotal;
}
@Override
public String toString() {
	return "ProductBean [productCode=" + productCode + ", productName=" + productName + ", productCategory="
			+ productCategory + ", productDescription=" + productDescription + ", productPrice=" + productPrice
			+ ", salesid=" + salesid + ", quantity=" + quantity + ", date=" + date + ", linetotal=" + linetotal + "]";
}


}
