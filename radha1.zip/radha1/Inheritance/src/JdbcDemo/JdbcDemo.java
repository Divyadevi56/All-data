package JdbcDemo;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

public class JdbcDemo {
	//private static final Statement DbConnection = null;

	public static void main(String[] args) throws SQLException  {
		try {
			//Class.forName("oracle.jdbc.driver.OracleDriver");
			//Connection con=DriverManager.getConnection("jdbc:oracle:thin:@10.219.34.3:1521:orcl","trg715","training715");
			Connection con=DbConnection.getConnection();
			Statement st=con.createStatement();
			st.executeUpdate("insert into dept values(10,'computer')");
			ResultSet rs=st.executeQuery("select * from dept");
			while(rs.next())
			{
				System.out.println(rs.getInt(1));
				System.out.println(rs.getString(2));
				//System.out.println(rs.getString(3));
			}
		
		} catch (Exception e) {
			// TODO Auto-generated catch block
			System.out.println(e);
		}
	}

}
