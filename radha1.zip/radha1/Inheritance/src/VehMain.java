
public class VehMain {

	public static void main(String[] args) {
		
		Vehicle v=new VehCar();
		v.transport();
		v.fuel();
		v.speed();
		//v.capacity();

	}

}
