package accountTypes;

import account.Account;

public class CurAcc extends Account
{

	public void cur() {
		// TODO Auto-generated method stub
System.out.println("current account");

	}
	public void display()
	{
		super.display();
		
	}

}
