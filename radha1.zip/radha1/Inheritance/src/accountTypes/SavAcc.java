package accountTypes;

import account.Account;

public class SavAcc extends Account
{
	public int i=20;

	 
public void display()
{
	System.out.println("a");
	super.display();
	
}

public void demo() {
	System.out.println("no data to add");
	// TODO Auto-generated method stub
/*System.out.println("saving account");
System.out.println(i);
System.out.println(super.i);*/
}
public void demo(int i)
{
	
	System.out.println(i);
}
public void demo(int i,int j)
{
	
	System.out.println(i+j);
}

}
