package demo;

public class SportsCar extends Car
{
	void  move()
	{
		System.out.println("sportscar");
	}
	/*int capacity()
	{
		System.out.println("sportscar capacity");
		return 0;
	}*/
	String fuel(String s)
	{
		 
		return s;
		
	}
	public String task()
	{
		String ob=new String();
		return ob;
		
	}
}
