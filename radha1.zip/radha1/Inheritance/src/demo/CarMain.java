package demo;

public class CarMain {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
SportsCar c=new SportsCar();
c.move();
c.capacity();
String a=c.fuel("petrol");
System.out.println(a);
System.out.println(c.task());
	}

}
