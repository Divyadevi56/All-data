package demo;

public class Car {

	void  move()
	{
		System.out.println("car");
	}
	final int capacity()
	{
		System.out.println("car capacity");
		return 0;
	}
	String fuel(String s)
	{
		 
		return s;
	}
	
	public Object task()
	{
		Object ob=new Object();
		return ob;
		
	}
	
}
