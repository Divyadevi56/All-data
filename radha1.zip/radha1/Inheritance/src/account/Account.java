package account;
public class Account {

	public int i=10;
	
	
		// TODO Auto-generated method stub
		public void display()
		{
		System.out.println("ACCOUNT");
		}
	}


