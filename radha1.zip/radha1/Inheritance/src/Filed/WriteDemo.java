package Filed;

import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;

public class WriteDemo {

	public static void main(String[] args) throws IOException {
		int i=0;
		
	FileOutputStream fo = new FileOutputStream("C:\\Users\\dsrikaka\\Desktop\\radha\\Inheritance\\divya.txt");
String s=new String("hello divya");
byte[] b=s.getBytes();
  fo.write(b);
  fo.close();
  
  FileInputStream fi = new FileInputStream("C:\\Users\\dsrikaka\\Desktop\\radha\\Inheritance\\divya.txt");
  
  
  while((i=fi.read())!=-1)
  {
	  System.out.print((char)i);
  }
  try(
	  FileReader inputStream =new FileReader("C:\\Users\\dsrikaka\\Desktop\\radha\\Inheritance\\divya.txt");
	  FileWriter outputStream = new FileWriter("C:\\\\Users\\\\dsrikaka\\\\Desktop\\\\radha\\\\Inheritance\\\\divya.txt");)
  {   
	  int c;
	  while((c=inputStream.read())!=-1)
	  {
		  outputStream.write(c);
	  }
  }
  catch(Exception e)
  {
	  System.out.println(e.getMessage());
  }
		 	  
 FileOutputStream fos=new FileOutputStream("C:\\Users\\dsrikaka\\Desktop\\radha\\Inheritance\\demo.txt");
 String s1=new String("hello divya");
 byte[] b1=s.getBytes();
   fos.write(b);
  
 DataOutputStream dos=new DataOutputStream(fos);
		  dos.writeInt(20);
		  dos.write(10);
		  dos.writeLong(30);
		  dos.writeDouble(400.00);
		  dos.write(Integer.MAX_VALUE);
		  dos.write(Byte.MIN_VALUE);
		  
DataInputStream dis=new DataInputStream("C:\\\\Users\\\\dsrikaka\\\\Desktop\\\\radha\\\\Inheritance\\\\demo.txt");
	}

}
