package Filed;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;

public class ProductMain {

	public static void main(String[] args) throws IOException {
		// TODO Auto-generated method stub
		try(FileOutputStream fs=new FileOutputStream("product");
ObjectOutputStream os=new ObjectOutputStream(fs);)
		{
         Product p=new Product(1,"fridge",1500);
         os.writeObject(p);
         }
		catch(Exception e)
		{
			System.out.println(e.getMessage());
		}
		
		try(FileInputStream fs1=new FileInputStream("product");
				ObjectInputStream ois=new ObjectInputStream(fs1);)
		{
			Product p1=new Product(1,"fridge",1500);
			Product a=(Product) ois.readObject();
			System.out.println(a);
			
		}
		catch(Exception e)
		{
			System.out.println(e.getMessage());
		}

}
}