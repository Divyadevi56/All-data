package JunitDemo;

import org.junit.After;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;

public class Calculator {
	

public int add(int a,int b)
{
	int c=a+b;
	return c;
}
public int sub(int a,int b)
{
	int d=a-b;
	return d;
}
public int  mul(int a,int b)
{
	return a*b;
}
public int div(int a,int b)
{
	return a/b;
}

}
