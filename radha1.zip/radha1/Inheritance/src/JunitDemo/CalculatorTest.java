package JunitDemo;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Ignore;
import org.junit.jupiter.api.Test;

class CalculatorTest {
	
	Calculator c=new Calculator();
	

	@Test
	void testAdd() {
		assertEquals(30, c.add(10, 20));
		
		
	}

	@Test
	void testSub() {
		assertEquals(-10,c.sub(10,20));
		
	}

	@Test
	void testMul() {
		assertEquals(200, c.mul(10,20));
	}

	@Test
	void testDiv() {
		assertEquals(2,c.div(20,10));
	}
	
	
	@Test
	@BeforeClass
	public void meth()
	{
		int i=10;
		System.out.println("execute task before start of tests"+i);
	}
	@After
	@Test
	public void display()
	{
		Calculator c=null;
		//System.out.println("cleanup task after each test is executed");
	}
	
	int j=20;
	@Before
	@Test
	
	public void dis()
	{
		
		System.out.println("can do initialization task before each test run"+j);
	}
	@AfterClass
	@Test
	void afclass()
	{
		//Calculator c=null;
		System.out.println("execute cleanup task after all tests have completed");
	}
	
	@Ignore
	void dummy()
	{
		System.out.println("to ignore the test method");
	}

}
