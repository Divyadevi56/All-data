package JunitDemo;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

class TestDate {

	@Test
	void test() {
		fail("Not yet implemented");
	}

}
