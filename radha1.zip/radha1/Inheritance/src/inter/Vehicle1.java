package inter;
public interface Vehicle1 {
void speed();
void fuel();
void brake();
default void meth()
{
	System.out.println("default");
}
static void meth1()
{
	
}
}
