package inter;

public interface Veh2 extends Veh3,Veh4 {
	int a=10;
void brake();
default void meth()
{
	System.out.println("default");
}

}
