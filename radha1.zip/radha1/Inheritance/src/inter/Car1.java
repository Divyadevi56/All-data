package inter;
public class Car1 implements Vehicle1,Veh2
{
public void speed()
{
	System.out.println("hi");
}

@Override
public void fuel() {
	System.out.println("hello");
	
}
public void brake()
{
	System.out.println("brake");
}
public void accelarate()
{
	System.out.println("accelarate");
}

@Override
public void meth()
{
	System.out.println("default");
}
}


