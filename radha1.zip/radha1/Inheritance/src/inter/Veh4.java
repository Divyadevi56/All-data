package inter;

public interface Veh4 {

}
