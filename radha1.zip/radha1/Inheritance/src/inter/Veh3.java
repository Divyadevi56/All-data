package inter;

public interface Veh3 {
void accelarate();
}
