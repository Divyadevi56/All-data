package inter;
public class VehicleMain {

	public static void main(String[] args) {
		Car1 c=new Car1();
		c.fuel();
		c.speed();
		c.brake();
		System.out.println(Veh2.a);

	}

}
