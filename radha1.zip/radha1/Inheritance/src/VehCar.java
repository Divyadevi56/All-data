
public class VehCar extends Vehicle{

	@Override
	void speed() {
		System.out.println("speed is 500");
		
	}

	@Override
	void fuel() {
		System.out.println("petrol");
		
	}
	void capacity()
	{
		System.out.println("capacity");
	}

}
