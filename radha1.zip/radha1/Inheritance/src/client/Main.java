package client;

import accountTypes.CurAcc;
import accountTypes.SavAcc;

public class Main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
SavAcc ac=new SavAcc();
ac.demo();
ac.demo(1);
ac.demo(100,300);

ac.display();


CurAcc cu = new CurAcc();
cu.cur();
cu.display();

	}

}
