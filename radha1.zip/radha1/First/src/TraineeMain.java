
public class TraineeMain {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
Trainee arr[]=new Trainee[3];
arr[0]= new Trainee(1,"sita",1500);
arr[1]=new Trainee(2,"geetha",2000);
arr[2]=new Trainee(3,"divya",3000);

for(int i=0;i<arr.length;i++)
{
	System.out.println(arr[i].toString());
	System.out.print(arr[i].empid+"\t");
	System.out.print(arr[i].empName+"\t");
	System.out.print(arr[i].salary+"\t");
	System.out.println();
	
}


	}

}
