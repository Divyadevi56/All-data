import java.util.ArrayList;
import java.util.Collections;
import java.util.Iterator;

public class MyStuMain {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
ArrayList<MyStudent> al=new ArrayList<MyStudent>();
al.add(new MyStudent(1, "divya", 20));
al.add(new MyStudent(2, "mahi", 22));
al.add(new MyStudent(3, "sowmya", 23));
al.add(new MyStudent(4, "anamika",20));
for(MyStudent index:al)
{
	System.out.println(index.age);
}
Collections.sort(al,new NameComparator());
System.out.println("after sorting");
for(MyStudent index:al)
{
	System.out.println(index.age);
}
Iterator it=al.iterator();
while(it.hasNext())
{
	MyStudent stu=(MyStudent) it.next();
	System.out.println(stu.name);
	System.out.println(stu.age);
	System.out.println(stu.rollno);
	
}



	}

}
