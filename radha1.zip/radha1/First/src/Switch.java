
public class Switch {

	public static void main(String[] args) {
		String currentDay=args[0];
		switch(currentDay)
		{
		case "MONDAY": 
		
		case "Tuesday":
		case "Wednesday":
		System.out.println("boring");
		break;
		case "Thursday":System.out.println("hello");
		break;
		case "Friday": System.out.println("hi");
		break;
		case "Saturday": System.out.println("saturday");
		break;
		case "sunday": System.out.println("happy");
		break;
		default: System.out.println("invalid case");
		break;
		
		}

	}

}
