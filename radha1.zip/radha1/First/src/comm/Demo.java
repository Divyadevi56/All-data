package comm;

import java.util.Scanner;

public class Demo {
	
	public static void main(String args[])
	{
		int uprc=0;
		int lowc=0;
	
		Scanner s=new Scanner(System.in);
		/*while(true)
		{*/
			System.out.println("whats your name?");
			String input=s.nextLine();
			/*if(input.isEmpty())
			{
				break;
			}
			System.out.println("Your name is"+input);
			break;
		}

		s.close();*/

	if(!input.isEmpty())
	{
		for(char ch:input.toCharArray())
		{
			if(!Character.isDigit(ch)&&Character.isAlphabetic(ch))
			{
				if(Character.isUpperCase(ch))
				{
					uprc++;
				}
				else
				{
					lowc++;
				}
				
			}
			
		}
	}
		System.out.println(uprc);
		System.out.println(lowc);
			s.close();
	}
	}
	


