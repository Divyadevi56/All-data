
public enum Months {

	Jan(31),Feb(28),Mar(31),Apr(30);

int days;


public int getDays() {
	return days;
}

public void setDays(int days) {
	this.days = days;
}




Months(int days)
{
	this.days=days;
}
}