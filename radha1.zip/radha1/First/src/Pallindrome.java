
public class Pallindrome {

	public static void main(String[] args) {
		int n=101;
		int rev=0;
		int a=n;
		while(n!=0)
		{
			int r=n%10;
			rev=rev*10+r;
			n=n/10;
		}
		if(a==rev)
		{
			System.out.println("Pallindrome");
		}
		else
		{
			System.out.println("Not Pallindrome");
		}
		

	}

}
