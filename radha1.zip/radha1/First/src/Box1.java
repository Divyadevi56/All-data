
public class Box1 {
	int length;
	int width;
	int height;
	Box1()
	{
		
	}
	Box1(int l,int w,int h)
	{
		this.length
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
