
public class If {

	public static void main(String[] args) {
		int age=20;
		if(age<=18)
		{
			System.out.println("not eligible to vote");
		}
		else
		{
			System.out.println("eligible to vote");
		}
		

	}

}
