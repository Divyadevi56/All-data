package sub;


abstract class Task {
	
	
		   public void demo()
		   {
		     System.out.println("Concrete method of parent class");
		   }
		   
		   abstract public void demo1();
		   abstract public void demo2(int i,int j);
		 }
		
		
