package sub;


public class Sub extends Task{
	
		int i=10;
		
	   
	   public void demo1()
	   {
	       System.out.println("implementing abstract method");
	       //System.out.println(i);
	   }
	   public void demo2(int i,int j)
	   {
		   System.out.println(i+j);
	   }
	   

}
