package sub;
public class TaskMain {
	 public static void main(String args[])
	   {
	       Sub obj = new Sub();
	       obj.demo();
	       obj.demo1();
	       
	       System.out.println(obj.i);
	       obj.demo2(10,30);
}
}
