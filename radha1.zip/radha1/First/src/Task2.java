
class Sub extends Task
		{
			int i=10;
			
		   
		   public void demo1()
		   {
		       System.out.println("overriding abstract method");
		   }
		}