
public class Trainee {

	 int empid;
	 String empName;
	 int salary;
	Trainee(int empid,String empName,int salary)
	{
		this.empid=empid;
		this.empName=empName;
		this.salary=salary;
	}
	@Override
	public String toString() {
		return "Trainee [empid=" + empid + ", empName=" + empName + ", salary=" + salary + "]";
	}
	
	
}
