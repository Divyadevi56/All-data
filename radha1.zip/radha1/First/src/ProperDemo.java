import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.Enumeration;
import java.util.Properties;

import org.omg.CORBA_2_3.portable.InputStream;
import org.omg.CORBA_2_3.portable.OutputStream;

public class ProperDemo {
	public static void saveProperties(Properties p,String fileName)
	{
		try
		{
			FileOutputStream propsFile =new FileOutputStream(fileName);
			p.store(propsFile,"Properties File to the test application");
			propsFile.close();
			
		}catch(IOException ioe)
		{
			
		}
	}
		private static Properties loadProperties(String fileName)
		{
			Properties tempProp=new Properties();
			try {
				FileInputStream propsFile=new FileInputStream(fileName);
				tempProp.load(propsFile);
				propsFile.close();
			}
			catch(IOException ioe)
			{
				System.out.println(ioe);
			}
			return tempProp;
		}
	
	private static Properties createDefaultProperties()
	{
		Properties tempProp=new Properties();
		tempProp.setProperty("url","jdbc:oracle:thin:@10.219.34.3:1521:orcl");
		tempProp.setProperty("driver","oracle.jdbc.driver.OracleDriver");
		tempProp.getProperty("username","trg715");
		tempProp.getProperty("password","training715");
		return tempProp;
	}
	public static void printprotperties(Properties p,String s)
	{
		p.list(System.out);
	}
	public static void main(String[] args) {
		final String PROPFILE="MyApplication.properties";
		Properties myProp;
		Properties myNewProp;
		myProp=createDefaultProperties();
		printprotperties(myProp,"Newly Created (Default) Properties");
		saveProperties(myProp,PROPFILE);
		myNewProp = loadProperties(PROPFILE);
		printprotperties(myNewProp,"Loaded Properties");
		//myNewProp=alterProperties(myProp);
		printprotperties(myNewProp,"After Altering properties");
		saveProperties(myNewProp,PROPFILE);
		Properties myNewProp1=loadProperties(PROPFILE);
		Enumeration enProps=myNewProp1.propertyNames();
		String key="";
		String param[];
		param=new String[4];
		int i=0;
		while(enProps.hasMoreElements())
		{
			key=(String)enProps.nextElement();
			System.out.println(key);
			param[i]=(String)myNewProp1.getProperty(key);
			System.out.println(" "+key+"->"+myNewProp1.getProperty(key));
			i++;
			
		}
		
		
		
	}
	

}
