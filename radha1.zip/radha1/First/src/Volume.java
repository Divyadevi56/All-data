


public class Volume {

	public static void main(String[] args) {
		
		//Box obj;
		//obj = new Box();
		//double a=Box.vol();
		//double a=obj.vol();
		//Box b1 = new Box(15,20.1,6);
		//double v=b1.vol();
		//System.out.println(a);
		//System.out.println(a);
		
		
		Box b2=new Box(10);
		Product o1=new Product();
		o1.setPid(10);
		o1.setPname("computer");
		o1.setPrice(1500);
	
		System.out.println(o1);
		System.out.println(o1.getPid());
		System.out.println(o1.getPname());
		System.out.println(o1.getPrice());
		

	}

}
