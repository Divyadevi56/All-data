import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.Scanner;

public class ParsingDate {

	public static void main(String[] args) {
		
		DateTimeFormatter formatter=DateTimeFormatter.ofPattern("dd/MM/yyyy");
		
		Scanner s=new Scanner(System.in);
		
		System.out.println("enter date in dd/MM/yyyy");
		String in=s.nextLine();
		
		LocalDate enteredDate=LocalDate.parse(in, formatter);
		
		System.out.println("Entered Date:"+enteredDate);
		s.close();

	}

}
