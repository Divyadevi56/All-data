package com;

public class Demo {
	

	public static void main(String[] args) {
		int uprc=0;
		int lowc=0;
		if(!input.isEmpty())
		{
			for(char ch:input.toCharArray())
			{
				if(!Character.isDigit(ch)&&Character.isAlphabetic(ch))
				{
					if(Character.isUpperCase(ch))
					{
						uprc++;
					}
				}
			}
