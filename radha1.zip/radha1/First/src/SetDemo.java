import java.util.SortedSet;
import java.util.TreeSet;

public class SetDemo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
SortedSet rs=new TreeSet();
rs.add("hh");
rs.add("hh");
rs.add("kk");


	}

}
