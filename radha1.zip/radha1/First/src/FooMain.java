
public class FooMain {
	
		  public static void main(String args[]) {
		    Car c = new Car(); 
		    c.setTyres(5); 
		    System.out.println("Tyres = "+c.getTyres()); 
		  }
}
