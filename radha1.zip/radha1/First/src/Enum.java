
public class Enum {

	public static void main(String[] args) {
		System.out.println(Months.Jan.getDays());

	}

}
