
public class MyStudent 
{

	
  int rollno;
  String name;
  int age;
 MyStudent(int rollno,String name,int age)
 {
	 this.rollno=rollno;
	 this.name=name;
	 this.age=age;
 }
 		
	}

	


