import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class MatcherDemo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
/*String in="Shop,Mop,Hopping,chopping";
Pattern pattern =Pattern.compile("hop");
Matcher matcher=pattern.matcher(in);
System.out.println(matcher.matches());
while(matcher.find())
{
	System.out.println(matcher.group()+":"+matcher.start()+":"+matcher.end());
}*/
  MatcherDemo o=new MatcherDemo();
  o.demo("Divya");
	o.phone("9676382741");
	o.email("d45ivya@capgemini.com");
	}
	
	void demo(String name)
	{
		
		Pattern p=Pattern.compile("[A-Z][a-z]{2,6}");
		Matcher matcher=p.matcher(name);
		System.out.println(matcher.matches());
	}
	void phone(String  phno)
	{
		
		Pattern p=Pattern.compile("[6-9][0-9]{9}");
		Matcher matcher=p.matcher(phno);
		System.out.println(matcher.matches());
	}
	void email(String  email)
	{
		Pattern p=Pattern.compile("\\\\b[A-Z0-9._%-]+@[A-Z0-9.-]+\\\\.[A-Z]{2,4}\\\");
		Matcher matcher=p.matcher(email);
		System.out.println(matcher.matches());
	}

}
