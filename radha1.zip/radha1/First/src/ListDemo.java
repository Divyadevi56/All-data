import java.util.ArrayList;
import java.util.LinkedList;

public class ListDemo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		ArrayList al=new ArrayList();
		al.add("sowmya");
		al.add("maheshwari");
		al.add("divya");
		al.add("chitra");
		al.addAll(al);
		System.out.println(al);
		System.out.println(al.contains("arun"));
		System.out.println(al.containsAll(al));
		System.out.println(al.size());
		System.out.println(al.remove("divya"));
		System.out.println(al);
		System.out.println(al.isEmpty());
		
		LinkedList ll=new LinkedList();
		ll.add("a");
		ll.add("a");
		ll.add("b");
		System.out.println(ll);
		
	
		

	}

}
