import static java.lang.Math.*;
public class Box
{
	double h;
	double w;
	double l;
 int count;
	
	
	
	
    public Box() {
		this(2);
		System.out.println("default constructor");
		// TODO Auto-generated constructor stub
		count++;
	}




	public Box(double h, double w, double l) {
		
		this.h = h;
		this.w = w;
		this.l = l;
		System.out.println("3 parameters");
		count++;
		
	}


public Box(int i) {
	this(4,55,6);
	System.out.println("1 parameter");
	count++;
}

	static double vol()
	{
	 //double v=l*w*h;
		
	 System.out.println(sqrt(15));
	 return 5;
	 
	}
}
