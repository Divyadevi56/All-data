

	public abstract class Foo {
		 private int tyres;
		 public void setTyres(int tyres) {
		   this.tyres = tyres;
		 } 
		 public int getTyres() {
		   return tyres;
		 } 
		}
		public class Car extends  {
		  public int getTyres() {
		     return super.getTyres()+1;
		  }


		}
		
		}

