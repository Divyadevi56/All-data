
public class Add {
	
	int a=10;
	int b=20;
	 void add()
	{
		 
		int result;
		result=a+b;
		System.out.println("Result is"+result);
		
	}

	public static void main(String args[])
	{
		Add o=new Add();
	
		o.add();
		
	}

}
