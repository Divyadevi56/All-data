package Excep;

public class ExcDemo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
ExcDemo o=new ExcDemo();
o.divide();
	}
	int a=10,b=0;
	String str=null;
	void divide()
	{
		
		int arr[]=new int[2];
		try
		{
			int c=a/b;
			System.out.println(c);
            System.out.println(arr[3]);	
            System.out.println(str.length());
		}
		
		catch(ArithmeticException  e1)
		{
			System.out.println(e1);
			//System.out.println("we should not divide with zero"+e);
		}
		catch(ArrayIndexOutOfBoundsException e1)
		{
			System.out.println(e1);
		}
		catch(Exception e2)
		{
			System.out.println(e2);
		}
	}

}
