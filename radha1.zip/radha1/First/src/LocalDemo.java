import java.time.LocalDate;
import java.time.Month;
import java.time.Period;
import java.time.ZoneId;
import java.time.ZonedDateTime;
import java.time.format.DateTimeFormatter;
import java.time.format.FormatStyle;

public class LocalDemo {

	public static void main(String[] args) {
		LocalDate localDate= LocalDate.now();
		
		System.out.println(localDate.plusDays(5));
		System.out.println(localDate.minusDays(15));
		System.out.println(localDate.isLeapYear());
		System.out.println(localDate.withDayOfMonth(30));
		System.out.println(localDate.lengthOfMonth());
		
		ZonedDateTime currentTime=ZonedDateTime.now();
		System.out.println(currentTime);
		
		ZonedDateTime currentTimeInParis=ZonedDateTime.now(ZoneId.of("Europe/Paris"));
		System.out.println(currentTimeInParis);
		
		DateTimeFormatter formatter = DateTimeFormatter.ofLocalizedDate(FormatStyle.FULL);
		System.out.println(localDate.format(formatter));
		
		DateTimeFormatter formatter1 = DateTimeFormatter.ofLocalizedDate(FormatStyle.LONG);
		System.out.println(localDate.format(formatter1));
		
		DateTimeFormatter formatter2 = DateTimeFormatter.ofLocalizedDate(FormatStyle.MEDIUM);
		System.out.println(localDate.format(formatter2));
		
		
		DateTimeFormatter formatter3 = DateTimeFormatter.ofLocalizedDate(FormatStyle.SHORT);
		System.out.println(localDate.format(formatter3));
		
		
		LocalDate dob=LocalDate.of(1996, Month.OCTOBER, 15);
		Period  period=dob.until(localDate);
		System.out.println(period.getYears());
		
		
		
		
		
		
		/*LocalDate independenceDay=LocalDate.of(1947, Month.AUGUST, 15);
		System.out.println(independenceDay);
		LocalDate obj=LocalDate.MAX;
		System.out.println(obj);
		LocalDate obj1=LocalDate.MIN;
		System.out.println(obj1);*/
		
		
		

	}

}
