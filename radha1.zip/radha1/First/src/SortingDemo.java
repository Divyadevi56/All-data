import java.util.ArrayList;
import java.util.Collections;

public class SortingDemo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
ArrayList<Student> al=new ArrayList<Student>();
al.add(new Student(1, "divya", 20));
al.add(new Student(2, "mahi", 22));
al.add(new Student(3, "sowmya", 23));
al.add(new Student(4, "anamika",20));
for(Student index:al)
{
	System.out.println(index.age);
}
Collections.sort(al);
System.out.println("after sorting");
for(Student index:al)
{
	System.out.println(index.age);
}



	}

}
