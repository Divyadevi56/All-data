import java.util.Arrays;

public class ArrayDemo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
int arr[]= {1,2,4,5,3};
for(int index:arr)
{
	System.out.println(index);
}
Arrays.sort(arr);
System.out.println();
System.out.println(Arrays.binarySearch(arr,4));

//System.out.println(Arrays.sort(arr));
int arr1[]=Arrays.copyOf(arr, 3);
for(int in:arr1)
{
	System.out.println(in);
}
int arr2[]=Arrays.copyOfRange(arr1, 0, 5);
for(int i:arr2)
{
	System.out.println(i);
}


	}

}
