
public class Fibonocci {

	public static void main(String[] args) {
		int a=0,b=1,c;
		System.out.println(a);
		System.out.println(b);
		int n=5;
		for(int i=1;i<n;i++)
		{
			 c=a+b;
			 System.out.println(c);
			 a=b;
			 b=c;
			
			 
		}
		

	}

}
