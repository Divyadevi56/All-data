package threadDemo;

public class JoinDemo {
public static void main(String[] args) {
/*	Thread t1=new Thread(new Thread1(),"first thread");
	Thread t2=new Thread(new Thread1(),"second thread");
	Thread t3=new Thread(new Thread1(),"third thread");
	t1.start();
	try
	{
		t1.join(1000);
		System.out.println(t1.MAX_PRIORITY);
	}catch(Exception e)
	{
		
	}
	t2.start();
	try
	{
		t1.join(1000);
		System.out.println(t2.MIN_PRIORITY);
	}catch(Exception e)
	{
		
	}
	t3.start();
	try
	{
		t1.join(1000);
		System.out.println(t3.NORM_PRIORITY);
	}catch(Exception e)
	{
		
	}*/
	Thread t=new Thread(new Thread1());
	t.start();
	t.isAlive();
	System.out.println();
	
	
}
}
