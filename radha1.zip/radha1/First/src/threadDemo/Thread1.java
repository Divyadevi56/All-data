package threadDemo;

public class Thread1 implements Runnable{
public static void main(String[] args) {
	
Thread1 t1=new Thread1();
}
	@Override
	public void run() {
		
		for(int r=2;r<5;r++)
		{
			for(int n=1;n<=10;n++)
			{
				
				System.out.print(r*n+" ");
				System.out.println("");
				//System.out.println();
				
			}
		}
		System.out.println(Thread.currentThread().getName());
		// TODO Auto-generated method stub
		
	}
	

}

