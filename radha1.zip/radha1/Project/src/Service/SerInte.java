package Service;

public interface SerInte {
       public abstract void BookDtails();
}
