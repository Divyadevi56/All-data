package Service;

public class SerImp implements SerInte{

	@Override
	public void BookDtails() {
		// TODO Auto-generated method stub
		int bid;
		String bname;
		int bprice;
		
	}
	

}
