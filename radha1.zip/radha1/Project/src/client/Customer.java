package client;

import java.util.Scanner;

public class Customer {
	int id;
	String name;

	public void customer(int id,String name) {
		// TODO Auto-generated method stub
Scanner sc=new Scanner(System.in);
System.out.println("enter phno");
int i=sc.nextInt();
System.out.println("enter name");
String s=sc.nextLine();
System.out.println("enter email");
String s1=sc.nextLine();

	}

}
