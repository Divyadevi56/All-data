package client;

import java.util.Scanner;

//import Entity.BookEntity;
import Entity.Customer;
import client.Customer;

public class Main {

	public static void main(String[] args) {
		
		Customer cd=new Customer();
		Scanner sc=new Scanner(System.in);
		System.out.println("enter cusid");
		int cid=sc.nextInt();
		
		
		
		
		

		


	}

}
