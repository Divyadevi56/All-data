import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Scanner;

public class CustomerDetails {

	public static void main(String[] args) throws SQLException {
		
	
		
		try {
			Class.forName("oracle.jdbc.driver.OracleDriver");
			Connection con=DriverManager.getConnection("jdbc:oracle:thin:@10.219.34.3:1521:orcl","trg715","training715");
			Statement st=con.createStatement();
			System.out.println("enter book name");
			Scanner sc=new Scanner(System.in);
			String s=sc.nextLine();
			PreparedStatement st1=con.prepareStatement("select * from book_details where bname=?");
		
			
			st1.setString(1,s);
			//st1.executeQuery();
			ResultSet rs=st1.executeQuery();
			
			while(rs.next())
			{
				System.out.println(rs.getInt(1));
				System.out.println(rs.getString(2));
				System.out.println(rs.getString(3));
				System.out.println(rs.getInt(4));
			}
		
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			//e.printStackTrace();
			System.out.println(e);
	}
	}
}
