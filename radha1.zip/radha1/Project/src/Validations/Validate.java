package Validations;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

import client.Customer;

public class Validate {

	
	
		public boolean  name(String name)
		{
			
			Pattern p=Pattern.compile("[A-Z][a-z]{2,6}");
			Matcher matcher=p.matcher(name);
			//System.out.println(matcher.matches());
			return true;
		}
		public boolean phone(String  phno)
		{
			
			Pattern p=Pattern.compile("[6-9][0-9]{9}");
			Matcher matcher=p.matcher(phno);
			//System.out.println(matcher.matches());
			return true;
		}
		public void email(String  email)
		{
			Pattern p=Pattern.compile("b[A-Z0-9._%-]+@[A-Z0-9.-]+.[A-Z]{2,4}");
			Matcher matcher=p.matcher(email);
			System.out.println(matcher.matches());
		}
}
