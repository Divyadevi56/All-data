package Entity;
public class Entity 
{
String cname;
int phno;
String mailid;
String address;
public String getCname() {
	return cname;
}
public void setCname(String cname) {
	this.cname = cname;
}
public int getPhno() {
	return phno;
}
public void setPhno(int phno) {
	this.phno = phno;
}
public String getMailid() {
	return mailid;
}
public void setMailid(String mailid) {
	this.mailid = mailid;
}
public String getAddress() {
	return address;
}
public void setAddress(String address) {
	this.address = address;
}


	
}
