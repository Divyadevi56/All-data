package Entity;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.util.Scanner;

import Validations.Validate;

public class CustomerDB {
	Scanner sc=new Scanner(System.in);
	Validate validate = new Validate();
	BookEntity book = new BookEntity();
	
	try {
		
		Class.forName("oracle.jdbc.driver.OracleDriver");
		Connection con=DriverManager.getConnection("jdbc:oracle:thin:@10.219.34.3:1521:orcl","trg715","training715");
		PreparedStatement pst=con.prepareStatement("insert into customer_details values(?,?,?,?)");

		/*System.out.println("enter id");
		String i=sc.next();
		int bookId= Integer.parseInt(i);
		book.setBookId(bookId);
		if(validate.phone(i)==true)
		{
			pst.setInt(1,book.getBookId());
		}*/
		
		
		
		System.out.println("enter customer name");
		String j=sc.next();
		pst.setString(1,j);
		
		System.out.println("enter phno");
		String a=sc.next();
		pst.setString(2,a);
		
		System.out.println("enter email");
		int b=sc.nextInt();
		pst.setInt(4,b);
		
		System.out.println("enter address");
		pst.executeUpdate();
		pst.setString(4,x);
		
		
		
		System.out.println("inserted");
		
}
