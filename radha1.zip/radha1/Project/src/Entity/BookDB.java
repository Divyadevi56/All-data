package Entity;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Scanner;

import Validations.Validate;

public class BookDB {

	public void book() throws SQLException {
		// TODO Auto-generated method stub
		Scanner sc=new Scanner(System.in);
		Validate validate = new Validate();
		BookEntity book = new BookEntity();
		
		try {
			
			Class.forName("oracle.jdbc.driver.OracleDriver");
			Connection con=DriverManager.getConnection("jdbc:oracle:thin:@10.219.34.3:1521:orcl","trg715","training715");
			PreparedStatement pst=con.prepareStatement("insert into book_details values(?,?,?,?)");
	
			System.out.println("enter id");
			String i=sc.next();
			int bookId= Integer.parseInt(i);
			book.setBookId(bookId);
			if(validate.phone(i)==true)
			{
				pst.setInt(1,book.getBookId());
			}
			
			
			
			System.out.println("enter name");
			String j=sc.next();
			pst.setString(2,j);
			
			System.out.println("enter author name");
			String a=sc.next();
			pst.setString(3,a);
			
			System.out.println("enter price");
			int b=sc.nextInt();
			pst.setInt(4,b);
			pst.executeUpdate();
			
			System.out.println("inserted");
			
			Statement st=con.createStatement();
			
			ResultSet rs=st.executeQuery("select * from book_details");
			
			while(rs.next())
			{
				System.out.println(rs.getInt(1));
				System.out.println(rs.getString(2));
				System.out.println(rs.getString(3));
			}
		}catch (ClassNotFoundException e) {
			System.out.println(e);

}
	}
}
