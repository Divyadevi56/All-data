package com.cg.donor.exception;

public class DonorException extends Exception{
	public DonorException(String name)
	{
		super(name);
	}

}
