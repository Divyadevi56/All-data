package com.cg.eis.exception;

public class EmployeeException extends Exception {
	void EmployeeException(String name)
	{
		System.out.println(name);

	}


}
