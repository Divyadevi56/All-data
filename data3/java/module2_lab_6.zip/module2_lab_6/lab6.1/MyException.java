package assignment;

public class MyException extends Exception {
	public MyException(String name)
	{
		System.out.println(name);

	}

}
