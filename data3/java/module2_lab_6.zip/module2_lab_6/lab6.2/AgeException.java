
public class AgeException extends Exception {

	AgeException(String name)
	{
		System.out.println(name);

	}

}
