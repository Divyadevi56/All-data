
package com.cg.eis.service;

public interface EmployeeService {
	public String setsInsurance(double salary);

}

