
public class Print {

	public static void main(String[] args) {
		String a="Divya";
		String b="Devi";
		char c='F';
	    int age=22;
		System.out.println("Person Details");
		System.out.println("----------------------");
		System.out.println("First Name :"+" "+a);
		System.out.println("Last Name :"+" "+b);
		System.out.println("Gender:\t"+c);
		System.out.println("Age:\t"+age);

	}

}
