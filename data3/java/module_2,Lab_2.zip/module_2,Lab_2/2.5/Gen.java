
public enum Gen {
	

			M,F;

		

}
