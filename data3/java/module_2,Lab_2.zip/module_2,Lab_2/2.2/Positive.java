
public class Positive {

	public static void main(String[] args) {
		int i=Integer.parseInt(args[0]);
		if(i<0)
		{
			System.out.println("Negative");
		}
		else
		{
			System.out.println("Positive");
		}

	}

}
